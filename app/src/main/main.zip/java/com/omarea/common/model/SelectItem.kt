package com.omarea.common.model

import java.io.Serializable

/*
示例1： 用于Spinner
ArrayAdapter(context, R.layout.kr_spinner_default, R.id.text, options).apply {
    setDropDownViewResource(R.layout.kr_spinner_dropdown)
}
*/

class SelectItem : Serializable {
    var title: String? = null
    // Kịch bản shell sinh title động cho 1 lựa chọn tĩnh
    var titleSh: String? = null
    // var desc: String = ""
    var value: String? = null
    var selected: Boolean = false

    override fun toString(): String {
        return if (!title.isNullOrEmpty()) {
            title!!
        } else if (!value.isNullOrEmpty()) {
            value!!
        } else {
            "" // super.toString()
        }
    }
}